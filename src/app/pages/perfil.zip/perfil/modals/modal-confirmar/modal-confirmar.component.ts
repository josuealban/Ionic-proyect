import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-modal-confirmar',
  templateUrl: './modal-confirmar.component.html',
  styleUrls: ['./modal-confirmar.component.scss'],
  standalone: true,
})
export class ModalConfirmarComponent  implements OnInit {

  constructor() { }

  ngOnInit() {}

}
