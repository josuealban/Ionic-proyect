import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-modal-editar',
  templateUrl: './modal-editar.component.html',
  styleUrls: ['./modal-editar.component.scss'],
  standalone: true,
})
export class ModalEditarComponent  implements OnInit {

  constructor() { }

  ngOnInit() {}

}
